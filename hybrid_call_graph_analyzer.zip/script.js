/*
  HYBRID INTERPROCEDURAL CALL GRAPH ANALYZER
  ---------------------------------------------------------
  Educational JavaScript prototype.

  Implemented concepts:
  1. Direct-call extraction
  2. Type-based candidate generation
  3. Lightweight pointer-target refinement
  4. Demand-driven reachability from main
  5. Fixed-point/worklist propagation
  6. SCC-based recursion/mutual-recursion detection
  7. Heuristic-guided inlining + simple constant propagation

  It is intentionally a browser parser/prototype, not a replacement
  for Clang/LLVM on arbitrary C/C++.
*/

const SAMPLE = `#include <stdio.h>

int square(int x) {
    return x * x;
}

int increment(int x) {
    return x + 1;
}

int recursive(int n) {
    if (n <= 0) return 0;
    return recursive(n - 1);
}

int even(int n) {
    if (n == 0) return 1;
    return odd(n - 1);
}

int odd(int n) {
    if (n == 0) return 0;
    return even(n - 1);
}

int main() {
    int (*fp)(int) = square;
    int a = fp(5);

    int (*gp)(int);
    gp = increment;
    int b = gp(a);

    recursive(3);
    even(4);

    printf("%d %d", a, b);
    return 0;
}`;

const state = {
  functions: new Map(),
  edges: [],
  reachable: new Set(),
  sccs: [],
  recursiveFunctions: new Set(),
  logs: [],
  dot: ""
};

const $ = id => document.getElementById(id);

function log(message) {
  state.logs.push(message);
}

function normalizeType(type) {
  return type
    .replace(/\b(const|volatile|static|extern|register)\b/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function parseParams(paramText) {
  const text = paramText.trim();
  if (!text || text === "void") return [];
  return text.split(",").map(p => {
    p = p.trim();
    const match = p.match(/(.+?)\s+([A-Za-z_]\w*)$/);
    return {
      type: normalizeType(match ? match[1] : p),
      name: match ? match[2] : `p${Math.random().toString(16).slice(2,5)}`
    };
  });
}

function stripComments(code) {
  return code
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/\/\/.*$/gm, "");
}

function findMatchingBrace(code, openIndex) {
  let depth = 0;
  for (let i = openIndex; i < code.length; i++) {
    if (code[i] === "{") depth++;
    else if (code[i] === "}") {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}

function extractFunctions(code) {
  const clean = stripComments(code);
  const map = new Map();

  const headerRegex =
    /(?:^|[;\n}])\s*(?:(?:static|inline|extern)\s+)?([A-Za-z_]\w*(?:\s*\*)?)\s+([A-Za-z_]\w*)\s*\(([^{};]*)\)\s*\{/g;

  let match;

  while ((match = headerRegex.exec(clean)) !== null) {
    const returnType = normalizeType(match[1]);
    const name = match[2];
    const params = parseParams(match[3]);
    const open = clean.indexOf("{", match.index);
    const close = findMatchingBrace(clean, open);

    if (close === -1) continue;

    const body = clean.slice(open + 1, close);

    map.set(name, {
      name,
      returnType,
      params,
      body,
      size: body.split(/\n/).filter(x => x.trim()).length || 1,
      signature: `${returnType} (${params.map(p => p.type).join(", ")})`,
      directCalls: [],
      indirectCalls: [],
      pointerAssignments: [],
      returnsFunctions: []
    });

    log(`Function discovered: ${name}`);
  }

  return map;
}

function functionTypeKey(fn) {
  return `${normalizeType(fn.returnType)}|${fn.params.map(p => normalizeType(p.type)).join(",")}`;
}

function parseCallArguments(text) {
  if (!text.trim()) return [];
  return text.split(",").map(x => x.trim());
}

function discoverCalls(fn, functions) {
  const body = fn.body;

  // Function pointer declarations/initialization:
  // int (*fp)(int) = foo;
  const ptrInitRegex =
    /(?:[\w\s\*]+)?\(\s*\*\s*(\w+)\s*\)\s*\(([^)]*)\)\s*=\s*(\w+)\s*;/g;

  let m;
  while ((m = ptrInitRegex.exec(body))) {
    fn.pointerAssignments.push({
      pointer: m[1],
      target: m[3],
      paramTypes: m[2].trim()
    });
  }

  // Function pointer assignment:
  // fp = foo;
  const ptrAssignRegex = /\b([A-Za-z_]\w*)\s*=\s*([A-Za-z_]\w*)\s*;/g;
  while ((m = ptrAssignRegex.exec(body))) {
    const left = m[1];
    const right = m[2];

    if (functions.has(right) && !/^(int|float|double|char|void|long|short)$/.test(right)) {
      fn.pointerAssignments.push({
        pointer: left,
        target: right,
        paramTypes: ""
      });
    }
  }

  // Direct calls. Ignore declarations and control constructs.
  const callRegex = /\b([A-Za-z_]\w*)\s*\(([^()]*)\)/g;
  while ((m = callRegex.exec(body))) {
    const name = m[1];

    if (["if", "for", "while", "switch", "sizeof", "return"].includes(name)) continue;

    const args = parseCallArguments(m[2]);

    if (functions.has(name)) {
      fn.directCalls.push({ target: name, args });
    }
  }

  // Indirect calls: fp(...), gp(...)
  const indirectRegex = /\b([A-Za-z_]\w*)\s*\(([^()]*)\)/g;
  while ((m = indirectRegex.exec(body))) {
    const name = m[1];

    if (functions.has(name)) continue;
    if (["if", "for", "while", "switch", "sizeof", "printf", "scanf"].includes(name)) continue;

    const priorText = body.slice(Math.max(0, m.index - 40), m.index);
    if (/\b(int|float|double|char|void|long|short)\s*$/.test(priorText)) continue;

    // Only retain calls that have evidence of a function-pointer symbol.
    if (new RegExp(`\\b${escapeRegex(name)}\\b`).test(
      fn.pointerAssignments.map(x => x.pointer).join(" ")
    )) {
      fn.indirectCalls.push({ pointer: name, args: parseCallArguments(m[2]) });
    }
  }

  // Return of a function identifier, e.g. return foo;
  const returnRegex = /\breturn\s+([A-Za-z_]\w*)\s*;/g;
  while ((m = returnRegex.exec(body))) {
    if (functions.has(m[1])) fn.returnsFunctions.push(m[1]);
  }
}

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/* ---------------------------------------------------------
   TYPE-BASED ANALYSIS
   --------------------------------------------------------- */

function typeBasedCandidates(fn, call) {
  const pointerAssignment = fn.pointerAssignments.find(
    a => a.pointer === call.pointer
  );

  let candidates = [];

  if (pointerAssignment && pointerAssignment.target && state.functions.has(pointerAssignment.target)) {
    const target = state.functions.get(pointerAssignment.target);
    candidates = [target.name];
  }

  // If assignment evidence is not available, use compatible signature
  // inferred from the indirect call's argument count.
  if (candidates.length === 0) {
    const argCount = call.args.length;

    for (const candidate of state.functions.values()) {
      if (candidate.params.length === argCount) {
        candidates.push(candidate.name);
      }
    }
  }

  log(
    `[TYPE] ${fn.name}: ${call.pointer} -> ` +
    `${candidates.length ? candidates.join(", ") : "no candidates"}`
  );

  return candidates;
}

/* ---------------------------------------------------------
   LIGHTWEIGHT POINTER ANALYSIS
   --------------------------------------------------------- */

function pointerAnalysis(fn, call) {
  const assignments = fn.pointerAssignments.filter(
    a => a.pointer === call.pointer
  );

  const targets = new Set();

  for (const a of assignments) {
    if (state.functions.has(a.target)) {
      targets.add(a.target);
    }
  }

  // Interprocedural return propagation:
  // if getFunc() returns foo, allow foo as a target.
  for (const candidate of state.functions.values()) {
    if (candidate.returnsFunctions.length > 0) {
      for (const returned of candidate.returnsFunctions) {
        if (state.functions.has(returned)) targets.add(returned);
      }
    }
  }

  const result = [...targets];

  log(
    `[POINTER] ${fn.name}: ${call.pointer} -> ` +
    `${result.length ? result.join(", ") : "unknown"}`
  );

  return result;
}

/* ---------------------------------------------------------
   HYBRID CALL GRAPH
   --------------------------------------------------------- */

function buildHybridGraph() {
  state.edges = [];

  for (const fn of state.functions.values()) {
    discoverCalls(fn, state.functions);
  }

  const addEdge = (from, to, kind) => {
    if (!state.edges.some(e => e.from === from && e.to === to && e.kind === kind)) {
      state.edges.push({ from, to, kind });
    }
  };

  for (const fn of state.functions.values()) {
    // Direct calls.
    for (const call of fn.directCalls) {
      addEdge(fn.name, call.target, "direct");
      log(`[DIRECT] ${fn.name} -> ${call.target}`);
    }

    // Indirect calls.
    for (const call of fn.indirectCalls) {
      const typeCandidates = typeBasedCandidates(fn, call);
      const pointerTargets = pointerAnalysis(fn, call);

      let refined = typeCandidates.filter(x => pointerTargets.includes(x));

      if (refined.length > 0) {
        for (const target of refined) {
          addEdge(fn.name, target, "pointer");
          log(`[HYBRID] ${fn.name} -> ${target} after type ∩ pointer refinement`);
        }
      } else if (pointerTargets.length > 0) {
        // Pointer evidence is useful even if the simplified type inference
        // could not recover the exact signature.
        for (const target of pointerTargets) {
          addEdge(fn.name, target, "pointer");
          log(`[HYBRID] ${fn.name} -> ${target} using pointer evidence`);
        }
      } else if (typeCandidates.length > 0) {
        for (const target of typeCandidates) {
          addEdge(fn.name, target, "type");
          log(`[FALLBACK] ${fn.name} -> ${target} using conservative type candidates`);
        }
      }
    }
  }
}

/* ---------------------------------------------------------
   DEMAND-DRIVEN FIXED-POINT / WORKLIST
   --------------------------------------------------------- */

function demandDrivenReachability() {
  state.reachable = new Set();

  if (!state.functions.has("main")) {
    log("[ERROR] No main() function found.");
    return;
  }

  const worklist = ["main"];
  state.reachable.add("main");

  log("[DEMAND] Starting analysis from main().");

  while (worklist.length) {
    const current = worklist.shift();

    for (const edge of state.edges.filter(e => e.from === current)) {
      if (!state.reachable.has(edge.to)) {
        state.reachable.add(edge.to);
        worklist.push(edge.to);

        log(
          `[WORKLIST] ${current} -> ${edge.to} discovered; ` +
          `${edge.to} added to analysis set.`
        );
      }
    }
  }

  log(
    `[DEMAND] Fixed point reached. ` +
    `${state.reachable.size} reachable functions.`
  );
}

/* ---------------------------------------------------------
   SCC / RECURSION DETECTION
   --------------------------------------------------------- */

function tarjanSCC(nodes, edges) {
  const adjacency = new Map();

  nodes.forEach(n => adjacency.set(n, []));
  edges.forEach(e => {
    if (adjacency.has(e.from) && adjacency.has(e.to)) {
      adjacency.get(e.from).push(e.to);
    }
  });

  let index = 0;
  const indices = new Map();
  const lowlink = new Map();
  const stack = [];
  const onStack = new Set();
  const result = [];

  function strongConnect(v) {
    indices.set(v, index);
    lowlink.set(v, index);
    index++;
    stack.push(v);
    onStack.add(v);

    for (const w of adjacency.get(v) || []) {
      if (!indices.has(w)) {
        strongConnect(w);
        lowlink.set(v, Math.min(lowlink.get(v), lowlink.get(w)));
      } else if (onStack.has(w)) {
        lowlink.set(v, Math.min(lowlink.get(v), indices.get(w)));
      }
    }

    if (lowlink.get(v) === indices.get(v)) {
      const component = [];

      while (true) {
        const w = stack.pop();
        onStack.delete(w);
        component.push(w);
        if (w === v) break;
      }

      result.push(component);
    }
  }

  nodes.forEach(v => {
    if (!indices.has(v)) strongConnect(v);
  });

  return result;
}

function detectRecursion() {
  const nodes = [...state.reachable];
  const edges = state.edges.filter(
    e => state.reachable.has(e.from) && state.reachable.has(e.to)
  );

  state.sccs = tarjanSCC(nodes, edges);
  state.recursiveFunctions = new Set();

  for (const component of state.sccs) {
    if (component.length > 1) {
      component.forEach(x => state.recursiveFunctions.add(x));
      log(`[SCC] Mutual recursion detected: ${component.join(" <-> ")}`);
    } else {
      const x = component[0];
      if (edges.some(e => e.from === x && e.to === x)) {
        state.recursiveFunctions.add(x);
        log(`[SCC] Direct recursion detected: ${x} -> ${x}`);
      }
    }
  }
}

/* ---------------------------------------------------------
   SIMPLE INTERPROCEDURAL OPTIMIZATION
   --------------------------------------------------------- */

function findConstantCalls(fn) {
  return fn.directCalls.filter(call =>
    call.args.length > 0 &&
    call.args.every(arg => /^-?\d+(\.\d+)?$/.test(arg))
  );
}

function evaluateSimpleReturn(fn, args) {
  let body = fn.body.trim();

  // Replace parameter names with numeric constants.
  fn.params.forEach((param, i) => {
    if (args[i] !== undefined && /^-?\d+(\.\d+)?$/.test(args[i])) {
      const re = new RegExp(`\\b${escapeRegex(param.name)}\\b`, "g");
      body = body.replace(re, args[i]);
    }
  });

  const ret = body.match(/return\s+([^;]+);/);
  if (!ret) return null;

  const expression = ret[1].trim();

  // Very small safe arithmetic evaluator for demo purposes.
  if (!/^[\d\s+\-*/%().]+$/.test(expression)) return null;

  try {
    // eslint-disable-next-line no-new-func
    const value = Function(`"use strict"; return (${expression})`)();
    if (Number.isFinite(value)) return String(value);
  } catch (_) {}

  return null;
}

function optimizationAnalysis() {
  const results = [];

  for (const fn of state.functions.values()) {
    if (!state.reachable.has(fn.name)) continue;

    if (state.recursiveFunctions.has(fn.name)) {
      results.push({
        type: "skip",
        title: `Do not inline ${fn.name}`,
        text: "The function belongs to a recursive SCC, so the heuristic rejects it."
      });
    }
  }

  for (const caller of state.functions.values()) {
    if (!state.reachable.has(caller.name)) continue;

    for (const call of findConstantCalls(caller)) {
      const callee = state.functions.get(call.target);
      if (!callee || state.recursiveFunctions.has(callee.name)) continue;

      const size = callee.size;
      const constantValue = evaluateSimpleReturn(callee, call.args);

      let score = 0;
      let reasons = [];

      // Explicit heuristic:
      // +5 constant arguments
      // +5 if constant propagation can simplify the result
      // +3 if callee is small
      // -10 if recursive
      if (call.args.every(x => /^-?\d+(\.\d+)?$/.test(x))) {
        score += 5;
        reasons.push("+5 constant arguments");
      }

      if (constantValue !== null) {
        score += 5;
        reasons.push("+5 constant propagation opportunity");
      }

      if (size <= 20) {
        score += 3;
        reasons.push("+3 small callee");
      }

      const inline = score >= 10;

      results.push({
        type: inline ? "inline" : "keep",
        title: `${caller.name} → ${callee.name}(${call.args.join(", ")})`,
        text: `Heuristic score = ${score}. ${reasons.join("; ") || "No positive factors."}`,
        transformed:
          constantValue !== null
            ? `Simple constant result: ${callee.name}(${call.args.join(", ")}) → ${constantValue}`
            : "No simple constant result detected."
      });

      log(
        `[INLINE] ${caller.name} -> ${callee.name}: ` +
        `score=${score}, decision=${inline ? "INLINE" : "KEEP OUT"}`
      );
    }
  }

  if (!results.length) {
    results.push({
      type: "info",
      title: "No optimization opportunity found",
      text: "Add a small function called with constant arguments to demonstrate the heuristic."
    });
  }

  return results;
}

/* ---------------------------------------------------------
   GRAPH RENDERING
   --------------------------------------------------------- */

function renderGraph() {
  const graph = $("graph");

  if (!state.functions.size) {
    graph.innerHTML = "<p>No graph yet. Click Analyze Program.</p>";
    return;
  }

  const nodes = [...state.functions.keys()];
  const activeNodes = nodes.filter(n => state.reachable.has(n));

  const columns = Math.max(1, Math.ceil(Math.sqrt(activeNodes.length)));
  const positions = new Map();

  activeNodes.forEach((name, i) => {
    const col = i % columns;
    const row = Math.floor(i / columns);
    positions.set(name, {
      x: 35 + col * 190,
      y: 35 + row * 125
    });
  });

  const width = Math.max(650, columns * 190 + 80);
  const rows = Math.ceil(activeNodes.length / columns);
  const height = Math.max(430, rows * 125 + 90);

  let html = `<div class="graph-inner" style="width:${width}px;height:${height}px">`;

  // Edges first.
  for (const edge of state.edges) {
    if (!positions.has(edge.from) || !positions.has(edge.to)) continue;

    const a = positions.get(edge.from);
    const b = positions.get(edge.to);

    const x1 = a.x + 65;
    const y1 = a.y + 45;
    const x2 = b.x + 65;
    const y2 = b.y + 45;

    const dx = x2 - x1;
    const dy = y2 - y1;
    const length = Math.sqrt(dx * dx + dy * dy);
    const angle = Math.atan2(dy, dx) * 180 / Math.PI;

    html += `
      <div class="edge ${edge.kind}"
           style="left:${x1}px;top:${y1}px;width:${length}px;transform:rotate(${angle}deg)">
      </div>
      <span class="edge-label" style="left:${(x1+x2)/2 - 25}px;top:${(y1+y2)/2 - 18}px">
        ${edge.kind}
      </span>`;
  }

  // Nodes.
  for (const name of activeNodes) {
    const fn = state.functions.get(name);
    const p = positions.get(name);
    const recursive = state.recursiveFunctions.has(name);

    html += `
      <div class="node" style="left:${p.x}px;top:${p.y}px;
           border-color:${recursive ? "#dc3545" : "#334155"}">
        <div class="name">${escapeHtml(name)}</div>
        <div class="size">${fn.size} line(s)${recursive ? " • recursive" : ""}</div>
      </div>`;
  }

  html += "</div>";
  graph.innerHTML = html;
}

function renderSteps() {
  const steps = [
    [
      "1. Function Extraction",
      `Detected ${state.functions.size} function definition(s) from the C source.`
    ],
    [
      "2. Type-Based Candidate Generation",
      "Indirect calls are assigned possible targets using compatible function signatures / observed pointer declarations."
    ],
    [
      "3. Pointer-Analysis Refinement",
      "Known assignments such as fp = foo are used to narrow the candidate target set."
    ],
    [
      "4. Demand-Driven Fixed Point",
      `Starting at main(), only ${state.reachable.size} reachable function(s) are retained for the demand-driven analysis.`
    ],
    [
      "5. SCC / Recursion Detection",
      `${state.sccs.filter(s => s.length > 1 || (s.length === 1 && state.recursiveFunctions.has(s[0]))).length} recursive SCC(s) detected.`
    ],
    [
      "6. Optimization",
      "A documented score-based heuristic evaluates safe small-function inlining and constant propagation opportunities."
    ]
  ];

  $("analysisSteps").innerHTML = steps.map(([title, text]) => `
    <div class="step">
      <strong>${title}</strong>
      <small>${escapeHtml(text)}</small>
    </div>
  `).join("");
}

function renderFunctionTable() {
  $("functionTable").innerHTML = [...state.functions.values()].map(fn => `
    <tr>
      <td><strong>${escapeHtml(fn.name)}</strong></td>
      <td><code>${escapeHtml(fn.signature)}</code></td>
      <td class="${state.reachable.has(fn.name) ? "yes" : "no"}">
        ${state.reachable.has(fn.name) ? "YES" : "NO"}
      </td>
      <td class="${state.recursiveFunctions.has(fn.name) ? "yes" : "no"}">
        ${state.recursiveFunctions.has(fn.name) ? "YES" : "NO"}
      </td>
      <td>${fn.size}</td>
    </tr>
  `).join("");
}

function renderOptimization(results) {
  $("optimizationResults").innerHTML = results.map(r => `
    <div class="opt-card">
      <h3>${escapeHtml(r.title)}</h3>
      <p>${escapeHtml(r.text)}</p>
      ${r.transformed ? `<p><strong>${escapeHtml(r.transformed)}</strong></p>` : ""}
      ${r.type === "inline" ? `
        <code>Decision: INLINE
Reason: heuristic threshold satisfied</code>` : ""}
      ${r.type === "skip" ? `
        <code>Decision: DO NOT INLINE
Reason: recursive SCC</code>` : ""}
    </div>
  `).join("");
}

function renderAll(results) {
  $("functionCount").textContent = state.functions.size;
  $("edgeCount").textContent = state.edges.length;
  $("reachableCount").textContent = state.reachable.size;
  $("sccCount").textContent =
    state.sccs.filter(s =>
      s.length > 1 || (s.length === 1 && state.recursiveFunctions.has(s[0]))
    ).length;

  renderSteps();
  renderGraph();
  renderFunctionTable();
  renderOptimization(results);
  $("log").textContent = state.logs.join("\n");
}

function analyze() {
  state.functions = extractFunctions($("sourceCode").value);
  state.edges = [];
  state.reachable = new Set();
  state.sccs = [];
  state.recursiveFunctions = new Set();
  state.logs = [];

  if (!state.functions.size) {
    log("No function definitions detected.");
    renderAll([]);
    return;
  }

  log("========== HYBRID ANALYSIS START ==========");
  buildHybridGraph();
  demandDrivenReachability();
  detectRecursion();

  const results = optimizationAnalysis();

  state.dot = generateDOT();

  log("========== HYBRID ANALYSIS COMPLETE ==========");
  renderAll(results);
}

function generateDOT() {
  let dot = "digraph CallGraph {\\n";
  dot += '  rankdir=LR;\\n';
  dot += '  node [shape=box, style="rounded"];\\n';

  for (const fn of state.functions.values()) {
    if (!state.reachable.has(fn.name)) continue;

    const label = state.recursiveFunctions.has(fn.name)
      ? `${fn.name}\\\\n[recursive]`
      : fn.name;

    dot += `  "${fn.name}" [label="${label}"];\\n`;
  }

  for (const edge of state.edges) {
    if (!state.reachable.has(edge.from) || !state.reachable.has(edge.to)) continue;

    dot += `  "${edge.from}" -> "${edge.to}" [label="${edge.kind}"];\\n`;
  }

  dot += "}\\n";
  return dot;
}

function downloadText(filename, text) {
  const blob = new Blob([text], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

$("sampleBtn").addEventListener("click", () => {
  $("sourceCode").value = SAMPLE;
});

$("clearBtn").addEventListener("click", () => {
  $("sourceCode").value = "";
  state.functions.clear();
  state.edges = [];
  state.reachable.clear();
  state.sccs = [];
  state.recursiveFunctions.clear();
  state.logs = [];
  $("analysisSteps").innerHTML = "";
  $("optimizationResults").innerHTML = "";
  $("functionTable").innerHTML = "";
  $("graph").innerHTML = "";
  $("log").textContent = "";
  $("functionCount").textContent = "0";
  $("edgeCount").textContent = "0";
  $("reachableCount").textContent = "0";
  $("sccCount").textContent = "0";
});

$("analyzeBtn").addEventListener("click", analyze);

$("downloadDotBtn").addEventListener("click", () => {
  if (!state.dot) analyze();
  downloadText("callgraph.dot", state.dot);
});

$("sourceCode").value = SAMPLE;
analyze();
